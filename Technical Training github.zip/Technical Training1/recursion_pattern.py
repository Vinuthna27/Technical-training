def fun(i,j):

r,c=map(int,input().split('X'))
f=fun(r,c)